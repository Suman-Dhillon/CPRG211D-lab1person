﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace lab1person
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person person1 = new Person(1, "Ian", "Brooks", "Red", 30, true);

            Person person2 = new Person(2, "Gina", "James", "Green", 18, false);

            Person person3 = new Person(3, "Mike", "Briscoe", "Blue", 45, true);

            Person person4 =new Person(4, "Mary", "Beals", "Yellow", 28, true);


            string nameinfo;
            nameinfo = person2.DisplayPersonInfo();
            Console.WriteLine(nameinfo + "\n");

            Console.WriteLine(person3.ToString());

            person1.ChangeFavoriteColor();
            Console.WriteLine(person1.DisplayPersonInfo());

            int ageAfter10yrs = person4.GetAgeInTenYears();
            Console.WriteLine("\n" + person4.FirstName + " " + person4.LastName + "'s age in 10 years: " + ageAfter10yrs + "\n");

            Relation relation1 = new Relation("Sister", person2, "Sister", person4);
            Relation relation2 = new Relation("Brother", person1, "Brother", person3);

            Console.WriteLine(relation1.ToString());
            Console.WriteLine(relation2.ToString());


            List<Person> listobj = new List<Person>();
            listobj.Add(person1);
            listobj.Add(person2);
            listobj.Add(person3);
            listobj.Add(person4);

            double totalage = 0;

            for (int i = 0; i < 4; i++)
            { 
                totalage += listobj[i].Age;
            }

            Console.WriteLine("Average age is: " + totalage / listobj.Count + "\n");

            int maxage = person1.Age;
            string maxagename = person1.FirstName;
            for (int i = 0; i < 4; i++)
            {
                if (listobj[i].Age > maxage)
                {
                    maxage = listobj[i].Age;
                    maxagename = listobj[i].FirstName;
                }
            }

            int minage = person1.Age;
            string minagename = person1.FirstName;
            for (int i = 0; i < 4; i++)
            {
                if (listobj[i].Age < minage)
                {
                    minage = listobj[i].Age;
                    minagename = listobj[i].FirstName;
                }
            }
            Console.WriteLine("The youngest person is: " + minagename);
            Console.WriteLine("The oldest person is: " + maxagename + "\n");

            string fn;
            for (int i = 0; i < 4; i++)
            {
                fn = listobj[i].FirstName;
                if (fn[0] == 'M')
                {
                    Console.WriteLine(listobj[i].ToString() + "\n");
                }
            }

            for (int i = 0; i < 4; i++)
            {
                if (listobj[i].FavoriteColor == "Blue")
                {
                    Console.WriteLine(listobj[i].ToString() + "\n");
                }
            }
        }
    }
}
