﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace lab1person
{
    internal class Person
    {
        private int personId;
        private string firstName;
        private string lastName;
        private string favoriteColor;
        private int age;
        private bool isWorking;

        public int PersonId { get { return personId; } set { personId = value; } }

        public string FirstName { get => firstName; set => firstName = value; }

        public string LastName { get => lastName;set => lastName = value; }

        public string FavoriteColor { get => favoriteColor;set => favoriteColor = value; }
        public int Age { get => age;set => age = value; }
        public bool IsWorking { get => isWorking; set => isWorking = value; }


        public string DisplayPersonInfo()
        {
            return (personId + ": " + FirstName + " " + LastName + "'s favorite color is " + FavoriteColor);
        }

        public void ChangeFavoriteColor()
        {
            FavoriteColor = "White";
        }

        public int GetAgeInTenYears()
        {
            return (Age + 10);
        }

        public Person(int personId, string firstName, string lastName, string favoriteColor, int age, bool isWorking)
        { 
            this.personId = personId;  
            this.firstName = firstName;
            this.lastName = lastName;
            this.favoriteColor = favoriteColor;
            this.age = age;
            this.isWorking = isWorking;
        }

        public override string ToString()
        {
            string formatted = "";

            formatted += "Person's ID: " + personId + "\n";
            formatted += "First Name: " + firstName + "\n";
            formatted += "Last Name: " + lastName + "\n";
            formatted += "Favorite Color: " + favoriteColor + "\n";
            formatted += "Age: " + age + "\n";
            formatted += "Is Working: " + isWorking + "\n";

            return formatted;
        }
    }
}
